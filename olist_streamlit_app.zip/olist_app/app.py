import json
import re
from pathlib import Path

import streamlit as st

st.set_page_config(
    page_title="Olist Capstone — نتائج الموديلات الخمسة",
    page_icon="📊",
    layout="wide",
)

BASE = Path(__file__).parent
SECTIONS_DIR = BASE / "assets" / "sections"

TAB_CONFIG = [
    ("overview", "🗂️ نظرة عامة", "التحضير المشترك للبيانات وتحليل EDA قبل الموديلات"),
    ("model1", "🔁 Model 1 — Return Prediction", "توقع احتمالية إلغاء/رجوع الأوردر (تصنيف ثنائي)"),
    ("model2", "🚚 Model 2 — Delivery Delay", "توقع تأخر التوصيل عن الموعد المتوقع (تصنيف ثنائي)"),
    ("model3", "⭐ Model 3 — Rating Prediction", "توقع تقييم العميل للأوردر (انحدار)"),
    ("model4", "👥 Model 4 — Customer Segmentation", "تقسيم العملاء لمجموعات باستخدام RFM (تجميع غير موجه)"),
    ("model5", "💰 Model 5 — Revenue Prediction", "توقع صافي الإيراد المتوقع من الأوردر (انحدار)"),
    ("overall", "📈 المقارنة الشاملة", "مقارنة أداء الخمس موديلات مع بعض"),
]


@st.cache_data
def load_section(key: str):
    path = SECTIONS_DIR / f"{key}.json"
    if not path.exists():
        return []
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def clean_markdown(text: str) -> str:
    # Downgrade H1/H2 headers inside notebook markdown so they don't fight the
    # Streamlit page/tab titles we already render.
    lines = text.split("\n")
    out = []
    for line in lines:
        if line.startswith("# "):
            continue  # skip top-level notebook title, we show our own
        if line.startswith("## "):
            line = "#### " + line[3:]
        elif line.startswith("### "):
            line = "##### " + line[4:]
        out.append(line)
    return "\n".join(out).strip()


def render_text_output(text: str):
    if not text or not text.strip():
        return
    if text.strip().startswith("<Figure"):
        return  # placeholder text for a figure that's already rendered as an image
    st.code(text.strip(), language=None)


def render_block(block: dict, model3_placeholder=False):
    kind = block.get("kind")
    if kind == "markdown":
        cleaned = clean_markdown(block["text"])
        if cleaned:
            st.markdown(cleaned)
    elif kind == "code_output":
        for tbl in block.get("tables", []):
            st.markdown(
                f'<div style="overflow-x:auto">{tbl}</div>',
                unsafe_allow_html=True,
            )
        for txt in block.get("texts", []):
            render_text_output(txt)
        imgs = block.get("images", [])
        if imgs:
            cols = st.columns(len(imgs)) if len(imgs) > 1 else [st]
            for col, img in zip(cols, imgs):
                img_path = BASE / img
                if img_path.exists():
                    col.image(str(img_path), use_container_width=True)


def render_section(key: str, subtitle: str):
    blocks = load_section(key)
    if not blocks:
        st.info("محتوى هذا الموديل غير متاح حاليًا — النوتبوك الأصلي لم يحتوِ على نتائج محفوظة لهذا القسم.")
        return
    st.caption(subtitle)
    st.divider()
    for block in blocks:
        render_block(block)


def main():
    st.title("📊 Olist Capstone — عرض نتائج الخمس موديلات")
    st.caption(
        "المحتوى المعروض هنا (الرسوم والجداول والنتائج) مأخوذ مباشرة من نوتبوك المشروع "
        "*Capstone_Models_1_to_5.ipynb*، بدون تحميل أو تشغيل أي موديل داخل هذا التطبيق."
    )

    tabs = st.tabs([label for _, label, _ in TAB_CONFIG])
    for tab, (key, label, subtitle) in zip(tabs, TAB_CONFIG):
        with tab:
            render_section(key, subtitle)


if __name__ == "__main__":
    main()
